PIXAROMA ALL WORKFLOWS

Every workflow from the Pixaroma ComfyUI course, one folder per episode.
40 episodes, made 2026-10-30. A fresh copy is made every time a new episode is published:
https://workflows.pixaroma.com/

NOT INCLUDED: the Media Inputs (the example pictures, audio, video and 3D models used in the
videos). They are in each episode's own zip. The episodes that have them are marked below:
open that episode's page and download its zip.

HOW TO ADD THEM TO COMFYUI
Copy this whole "Pixaroma All Workflows" folder into your workflows folder:
  Easy-Install: ComfyUI-Easy-Install/ComfyUI/user/default/workflows
  Portable:     ComfyUI_windows_portable/ComfyUI/user/default/workflows
  (no "workflows" folder there yet? make one)
Then in ComfyUI open the Workflows panel on the left and press its refresh button.
Quick option: drag a .json file straight onto the ComfyUI canvas.
1 minute video: https://workflows.pixaroma.com/help/open-workflow/
Missing nodes or models? Watch that episode's video. Help: https://workflows.pixaroma.com/help/

EPISODES

Ep01  ComfyUI Course - Learn ComfyUI From Scratch | Full 5 Hour Course
      https://workflows.pixaroma.com/ep/1/

Ep02  ComfyUI Nunchaku Tutorial: Install, Models, and Workflows Explained
      https://workflows.pixaroma.com/ep/2/

Ep03  ComfyUI Qwen VL3: Creating Prompts from Images and Text
      https://workflows.pixaroma.com/ep/3/

Ep04  AI Image Editing in ComfyUI: Flux 2 Klein
      https://workflows.pixaroma.com/ep/4/

Ep05  How to Upscale Images in ComfyUI
      https://workflows.pixaroma.com/ep/5/

Ep06  ComfyUI Video Models: InfiniteTalk + Wan 2.2 + SCAIL + LTX-2
      https://workflows.pixaroma.com/ep/6/

Ep07  Free AI voice in ComfyUI, Qwen3-TTS Clone Voice and Custom Voice Design
      https://workflows.pixaroma.com/ep/7/

Ep08  ComfyUI for Image Manipulation: Remove BG, Combine Images, Adjust Colors
      https://workflows.pixaroma.com/ep/8/

Ep09  FLUX.2 Klein 9B KV: Speed and Image Consistency in ComfyUI
      https://workflows.pixaroma.com/ep/9/

Ep10  How to Use Fish Audio S2 Text to Speech in ComfyUI
      https://workflows.pixaroma.com/ep/10/

Ep11  I Went Full Mad Scientist in ComfyUI - Pixaroma Nodes
      https://workflows.pixaroma.com/ep/11/

Ep12  Vibe Code Your First ComfyUI Custom Node Step by Step
      https://workflows.pixaroma.com/ep/12/

Ep13  ComfyUI Pixaroma Nodes Update 2: Better Composer, 3D Builder, Paint
      https://workflows.pixaroma.com/ep/13/

Ep14  Ernie Model in ComfyUI - Worth It? + New Nodes Guide
      https://workflows.pixaroma.com/ep/14/

Ep15  Make Images React to Music in ComfyUI + ACE-Step AI Music
      https://workflows.pixaroma.com/ep/15/

Ep16  Qwen 3.5 in ComfyUI + Align Tool & Pixaroma Nodes Updates
      https://workflows.pixaroma.com/ep/16/

Ep17  ComfyUI Pixaroma Nodes: New Load Image, Notify & Utility Nodes
      https://workflows.pixaroma.com/ep/17/

Ep18  Gemma 4 + New ComfyUI Nodes That Make Prompting Easy!
      https://workflows.pixaroma.com/ep/18/

Ep19  Stable Audio 3 in ComfyUI: Create AI Music and Sound Effects
      https://workflows.pixaroma.com/ep/19/

Ep20  ComfyUI Anima Base & Microsoft Lens + New Pause Image Node
      https://workflows.pixaroma.com/ep/20/

Ep21  ComfyUI XY Plot & Find/Replace Nodes + GitHub Suspended My Account
      https://workflows.pixaroma.com/ep/21/

Ep22  ComfyUI Inpainting + Batch Load Images from a Folder
      https://workflows.pixaroma.com/ep/22/

Ep23  ComfyUI Scail 2 Video: WiFi Nodes, New Groups & Loops
      https://workflows.pixaroma.com/ep/23/

Ep24  ComfyUI Krea 2 Workflows for Better Text to Image Results
      https://workflows.pixaroma.com/ep/24/

Ep25  ComfyUI INT8 Performance Boost! Boogu, Krea2 & Z-Image
      https://workflows.pixaroma.com/ep/25/

Ep26  Train Krea 2 LoRA Online, Use It Locally in ComfyUI
      https://workflows.pixaroma.com/ep/26/

Ep27  How to Outpaint in ComfyUI + New Control Panel, Run Log & Text Join
      https://workflows.pixaroma.com/ep/27/

Ep28  Pause LLM Text and Create a Reusable Prompt Library in ComfyUI
      https://workflows.pixaroma.com/ep/28/

Ep29  ComfyUI MiniMax H3: Best Video Generation Workflows
      https://workflows.pixaroma.com/ep/29/
      Media Inputs (11 files) are in this episode's own zip

Ep30  ComfyUI Krea 2 Edit + MiniMax H3 Prompts Generated Locally
      https://workflows.pixaroma.com/ep/30/
      Media Inputs (6 files) are in this episode's own zip

Ep31  MiniMax Music 3 + Local AI Prompt Generator
      https://workflows.pixaroma.com/ep/31/

Ep32  ComfyUI MiniMax H3 Speed LoRA + VRAM Monitor Nodes
      https://workflows.pixaroma.com/ep/32/
      Media Inputs (5 files) are in this episode's own zip

Ep33  Image to 3D Made Easy: Trellis 2 + Pixal3D in ComfyUI
      https://workflows.pixaroma.com/ep/33/
      Media Inputs (2 files) are in this episode's own zip

Ep34  Pixal3D Multiview in ComfyUI | Load & Save 3D Nodes
      https://workflows.pixaroma.com/ep/34/
      Media Inputs (9 files) are in this episode's own zip

Ep35  MiniMax FastH3 in ComfyUI | Text to Video and Image to Video
      https://workflows.pixaroma.com/ep/35/
      Media Inputs (3 files) are in this episode's own zip

Ep36  ComfyUI Qwen Image 2.1 Tutorial | Generate, Edit, Inpaint & More
      https://workflows.pixaroma.com/ep/36/
      Media Inputs (24 files) are in this episode's own zip

Ep37  Free AI Model for Design & Text in ComfyUI | Ming Image 0.1
      https://workflows.pixaroma.com/ep/37/
      Media Inputs (6 files) are in this episode's own zip

Ep38  50 Free ComfyUI Automation Workflows
      https://workflows.pixaroma.com/ep/38/
      Media Inputs (21 files) are in this episode's own zip

Ep39  Flux 3 Klein in ComfyUI | Generate, Edit & Combine Images
      https://workflows.pixaroma.com/ep/39/
      Media Inputs (11 files) are in this episode's own zip

Ep40  MOSS Image in ComfyUI | Text to Image, Words & Layout
      https://workflows.pixaroma.com/ep/40/
      Media Inputs (2 files) are in this episode's own zip
